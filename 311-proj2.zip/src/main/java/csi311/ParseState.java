package csi311;

import java.awt.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.databind.ObjectMapper;

import csi311.MachineSpec.StateTransitions; 

public class ParseState {

	public ParseState() {
	}
	
	// to use state as a key and transition as a value
	static HashMap<String, String> map = new HashMap<String, String>();
	
	// Array of all of states from states and transitions
	static ArrayList<String> allStates = new ArrayList<String>();
	// Array of states from states of machine.in
	static ArrayList<String> stateFromState = new ArrayList<String>();
	// Array of states from transitions of machine.in
	static ArrayList<String> stateFromTransition = new ArrayList<String>();
	// to distinguish possible start states
	static ArrayList<String> possibleStartState = new ArrayList<String>();
	// to distinguish terminal states
	static ArrayList<String> terminalState = new ArrayList<String>();
	
    public void run(String filename) throws Exception {
    	//System.out.println("Parse State");
    	if (filename != null) {
    		String json = processFile(filename); 
    		//System.out.println("Raw json = " + json); 
    		MachineSpec machineSpec = parseJson(json);
    		dumpMachine(machineSpec); 
    	}
    }
    
    
    private void dumpMachine(MachineSpec machineSpec) {
    	if (machineSpec == null) {
    		return;
    	}
    	
    	for (StateTransitions st : machineSpec.getMachineSpec()) {
    		//System.out.println(st.getState() + " : " + st.getTransitions());
    		
    		// make hashmap ( key:state, value:transition)
    		map.put(st.getState().toUpperCase(), st.getTransitions().toString().toUpperCase());
    		
    		// to get states from transitions
    		for(int i=0; i<st.getTransitions().size(); i++) {
    			if(!stateFromTransition.contains(st.getTransitions().get(i).toUpperCase()))
    			{
    				stateFromTransition.add(st.getTransitions().get(i).toUpperCase());	
    			}
    		}
    		
    		// to get possible start states
    		for(int i=0; i<st.getTransitions().size(); i++) {
    			if(st.getState().toUpperCase().equals("START")) {
    				possibleStartState.add(st.getTransitions().get(i).toUpperCase());
    			}
    		}
    	}
    	
    	/*
    	System.out.println("possible start states");
    	System.out.println(possibleStartState);
    	System.out.println("possible transitions of each state");
    	System.out.println(map);
    	System.out.println("States from Transition (of machine.in)");
    	System.out.println(stateFromTransition);
    	*/
    	
    }
    
    
    private String processFile(String filename) throws Exception {
    	//System.out.println("Processing file: " + filename); 
    	BufferedReader br = new BufferedReader(new FileReader(filename));
    	String json = "";
    	String line;
    	while ((line = br.readLine()) != null) {
    		json += " " + line; 
    	} 
    	br.close();
    	// Get rid of special characters - newlines, tabs.  
    	return json.replaceAll("\n", " ").replaceAll("\t", " ").replaceAll("\r", " "); 
    }

    
    private MachineSpec parseJson(String json) {
        ObjectMapper mapper = new ObjectMapper();
        try { 
        	MachineSpec machineSpec = mapper.readValue(json, MachineSpec.class);
        	return machineSpec; 
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        return null;  	
    }
    
    // check if current id and next id are same
    public static boolean sameId(String formerID, String currentID) {
    	if(formerID.equals(currentID)) {
    		return true;
    	} else {	
    		return false;
    	}
    }
    
    // check if the state transition is malformed
    public static boolean isGoodTransition(String formerState, String currentState) {
    	if(stateFromState.contains(formerState) && map.get(formerState).contains(currentState)) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    
    public static void readText(String filename) throws Exception {
    	// ArrayList for wrong Ids
    	ArrayList<String> flag = new ArrayList<String>();
    	
    	
    	BufferedReader br = new BufferedReader(new FileReader(filename));  
    	String line = null;
    	
    	
    	// patterns
    	String timestamp_pattern = "\\d{13}";
    	String orderid_pattern = "^\\d\\d\\d-[A-Z][A-Z][A-Z]-\\d\\d\\d\\d";
    	String customerid_pattern = "\\d{9}";
    	String quantity_pattern = "\\d+";
    	String price_pattern = "\\d+\\.\\d+";
    	
    	int keysetLength = map.keySet().toArray().length;
    	//System.out.println("keyset Length is : " + keysetLength);
    	
    	// add state to allStates from states(keys) 
    	for(int i=0; i<keysetLength; i++) {
    		if(!allStates.contains(map.keySet().toArray()[i].toString().toUpperCase())) {
    			allStates.add(map.keySet().toArray()[i].toString().toUpperCase());
    		}
    	}
    	
    	// add state to allStates from transitions(values)
    	for(int i=0; i<stateFromTransition.size(); i++) {
    		if(!allStates.contains(stateFromTransition.get(i))) {
    			allStates.add(stateFromTransition.get(i));
    		}
    	}
    	
    	for(int i=0; i<map.keySet().size(); i++) {
    		stateFromState.add(map.keySet().toArray()[i].toString().toUpperCase());
    	}
    	
    	/*
    	System.out.println("state from state (of machine.in)");
    	System.out.println(stateFromState);
    	*/
    	
    	// Terminal states (which do not have transitions = not states from keys)
    	for(int i=0; i<stateFromTransition.size(); i++)
    	{
    		if(stateFromState.contains(stateFromTransition.get(i))) {
    			// this state is not a terminal state
    		} else {
    			terminalState.add(stateFromTransition.get(i));
    		}
    	}
    	
    	/*
    	System.out.println("Terminal States");
    	System.out.println(terminalState);
    	
    	System.out.println("All Posible States");
    	System.out.println(allStates);
    	*/
    	
    	// to print total price and number of states at the end
    	String[] statesList = new String[allStates.size()];
    	for(int i=0; i<allStates.size(); i++) {
    		statesList[i] = allStates.get(i);
    		//System.out.println("States list[" + i + "] = " + statesList[i]);
    	}
    	double[] priceSum = new double[statesList.length];
    	for(int i=0; i<priceSum.length; i++) {
    		priceSum[i] = 0.0;
    	}
    	int[] countSum = new int[statesList.length];
    	for(int i=0; i<countSum.length; i++) {
    		countSum[i] = 0;
    	}
    	
    	
    	
    	System.out.println("Tru State");
    	
    	line = br.readLine();
    	String[] currentResult = line.split(",");
    	if(currentResult.length != 7) {	// if the first line has malformed length
    		br.readLine();
    	}
    	String currentTimeStamp = currentResult[0].trim();
    	String currentOrderId = currentResult[1].trim().toUpperCase();
    	String currentCustomerId = currentResult[2].trim();
    	String currentState = currentResult[3].trim().toUpperCase();
    	String currentQuantity = currentResult[5].trim();
    	String currentPrice = currentResult[6].trim();
    	
    	String idToken = null;
    	String stateToken = null;
    	double priceToken = 0.0;
    	
        while (line != null) {
        	
        	// to skip the blank line
        	if (line.trim().length() == 0) {
        		continue;
        	}
        	
        	// if line doesn't contain ",", skip the line
        	if (!line.contains(",")) {
        		continue;
        	}
        	
        	// split the line by comma
        	String[] result = line.split(",");
        	String timestamp = result[0].trim();
        	String orderid = result[1].trim().toUpperCase(); // basically next order id
        	String customerid = result[2].trim();
        	String state1 = result[3].trim().toUpperCase(); // basically next state
        	String quantity = result[5].trim();
        	String price = result[6].trim();
        	
        	// check if the quantity can be counted and the price can be added
        	boolean isCount = true;
        	boolean isAdd = true;
        	
        	// check if the time stamp pattern agrees
        	if(!currentTimeStamp.matches(timestamp_pattern)) { 
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	// 6 commas, so it has to have length 7
        	if(result.length != 7) {
        		continue;
        	}
        	
        	/*
        	if(!currentOrderId.matches(orderid_pattern)) {
        		isPerfect = false;
        	}
        	*/
        	
        	// check if the customer id pattern agrees
        	if(!currentCustomerId.matches(customerid_pattern)) {
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	if(sameId(currentOrderId,orderid) && !currentCustomerId.equals(customerid)) {
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	// check if state has a correct state name
        	boolean checkCorrectStateName = false;
        	
        	for(int i = 0; i < allStates.size(); i++) {
        		if(allStates.contains(currentState)) {
        			checkCorrectStateName = true;
        		}
        	}
        	if(checkCorrectStateName == false) {
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	// check if the quantity pattern agrees
        	if(!currentQuantity.matches(quantity_pattern)) {
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	// check if the price pattern agrees
        	if(!currentPrice.matches(price_pattern)) {
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	
        	// state -> wrong transition, flag
        	if(sameId(currentOrderId,orderid) && !isGoodTransition(currentState, state1)) {
        		System.out.println("Flagging order " + currentOrderId);
        		if(!flag.contains(currentOrderId)) {
        			flag.add(currentOrderId);
        		}
        		isCount = false;
        		isAdd = false;
        	}
        	
        	
        	// invalid start state
        	if(!sameId(currentOrderId,orderid) && !possibleStartState.contains(state1)) {
        		System.out.println("Flagging order " + orderid);
        		if(!flag.contains(orderid)) {
        			flag.add(orderid);
        		}
        		isCount = false;
        	}
        	
        	// when addition of price is not available (counting the quantity doesn't matter in this situation)
        	if(sameId(currentOrderId,orderid) && isGoodTransition(currentState,state1)) {
        		isAdd = false;
        	}
        	if(sameId(currentOrderId,orderid) && terminalState.contains(currentState)) {
        		isAdd = false;
        	}
        	
        	// my code couldn't catch this situation, so I made it
        	if(!sameId(currentOrderId,orderid) && !possibleStartState.contains(state1))
        	{
        		idToken = String.valueOf(orderid);
        		stateToken = String.valueOf(state1);
        		priceToken = Double.parseDouble(price);
        	}
        	
        	// calculate count sum of each state
        	for(int i=0; i<statesList.length; i++) {
        		if(isCount && statesList[i].equals(currentState) && !sameId(currentOrderId,orderid)) {
            			countSum[i] += Integer.parseInt(currentQuantity);
            	}
        	}
        	
        	// calculate price sum of each state
        	for(int i=0; i<statesList.length; i++) {
        		if(isAdd && statesList[i].equals(currentState) && !sameId(currentOrderId,orderid)) {
            			priceSum[i] += Double.parseDouble(currentPrice);
            	}
        		// take away the token value
        		if(statesList[i].equals(stateToken)) {
    				priceSum[i] -= priceToken;
    				idToken = null;
    				stateToken = null;
    				priceToken = 0.0;	
            	}
        		
        	}
        	
        	line = br.readLine(); // go to next line
        	currentTimeStamp = timestamp;
        	currentOrderId = orderid;
        	currentCustomerId = customerid;
        	currentState = state1;
        	currentQuantity = quantity;
        	currentPrice = price;
        }
        
        for(int i=0; i<statesList.length; i++) {
        	// do not count if priceSum of state is zero
        	if(priceSum[i] >= 0.00001) {
        		if(terminalState.contains(statesList[i])){ // round funciton -> to round up to 2 decimal places
            		System.out.println(statesList[i] + " " + countSum[i] + " $" + Math.round(priceSum[i]*100)/100.0 + " (terminal)");
            	} else {
            		System.out.println(statesList[i] + " " + countSum[i] + " $" + Math.round(priceSum[i]*100)/100.0);
            	}
        	}
        }
        
        //System.out.println("Malformed ID: \n");
        //System.out.println(flag);
        System.out.println("flagged " + flag.size());
        
        br.close();
    }

    
    public static void main(String[] args) {
    	ParseState theApp = new ParseState();
    	String filename = null;  // machine.in
    	String orderFile = null;  //orders.in
    	if (args.length > 0) {
    		filename = args[0];
    		orderFile = args[1];
    	}
    	try { 
    		theApp.run(filename);
    		readText(orderFile);
    	}
    	catch (Exception e) {
    		System.out.println("Something bad happened!");
    		e.printStackTrace();
    	}
    }	
	
	

}
