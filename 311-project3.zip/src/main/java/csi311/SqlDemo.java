package csi311;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.apache.derby.jdbc.EmbeddedDriver;

import com.fasterxml.jackson.databind.ObjectMapper;

import csi311.MachineSpec.StateTransitions;


public class SqlDemo {

	private static final String DB_URL = "jdbc:derby:csi311-testdb1;create=true";
    private Connection conn = null;
    private Statement stmt = null;
	
    private String writingFile = "allorders.in";
    
    // Keep a list of orders, keyed by order id
 	private Map<String,Order> orders = new HashMap<String,Order>(); 
 	// The state machine for this run
 	private MachineSpec machineSpec; 

	public SqlDemo() {
	}
	
	
    public void loadStateMachine(String jsonFilePath) throws Exception {
        createConnection();
        createStateMachineTable();
        
        String json = processStateFile(jsonFilePath);
        MachineSpec statemachine = parseJson(json);
        int id = statemachine.getTenantId();
        insertStateMachine(id,json);
        //insertRestaurant("LaVals", "Berkeley");
        //selectRestaurants();
        shutdown();
    }
    
    /*
    // Read in the state machine and the order file.  Make a report.  
    public void run(String stateFilename, String orderFilename) throws Exception {
    	System.out.println("Tru State");
   		String json = processStateFile(stateFilename); 
   		machineSpec = parseJson(json);
   		dumpMachine(machineSpec); 
   		processOrderFile(orderFilename); 
   		makeReport();
    }
     */
    
    // For debugging, dump out the state machine we think we read in.
    @SuppressWarnings("unused")
	private void dumpMachine(MachineSpec machineSpec) {
    	if (machineSpec == null) {
    		return;
    	}
    	for (StateTransitions st : machineSpec.getMachineSpec()) {
    		System.out.println(st.getState() + " : " + st.getTransitions());
    	}
    }
    
    
    // Read in the state machine file to a string.  Convert newline characters if needed.
    private String processStateFile(String filename) throws Exception {
    	BufferedReader br = new BufferedReader(new FileReader(filename));  
    	String json = "";
    	String line; 
    	while ((line = br.readLine()) != null) {
    		json += " " + line; 
    	} 
    	br.close();
    	// Get rid of special characters - newlines, tabs.  
    	return json.replaceAll("\n", " ").replaceAll("\t", " ").replaceAll("\r", " "); 
    }


    // Use the Jackson library to deserialize the state machine from a string into an object.
    private MachineSpec parseJson(String json) {
        ObjectMapper mapper = new ObjectMapper();
        try { 
        	MachineSpec machineSpec = mapper.readValue(json, MachineSpec.class);
        	return machineSpec; 
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        return null;  	
    }
    
    
    // Iterate over the lines of the order file.  
    private void processOrderFile(String orderFilename) throws Exception {
    	// Open the file and connect it to a buffered reader.
    	BufferedReader br = new BufferedReader(new FileReader(orderFilename));  
    	String line = null;  
    	// Get lines from the file one at a time until there are no more.
    	while ((line = br.readLine()) != null) {
    		// Process the line
    		processOrder(line);
    	} 
    	// Close the buffer and the underlying file.
    	br.close();
    }
    

    // Iterate over the lines of the order file.  
    private void allorders(String orderFilename) throws Exception {
    	// Open the file and connect it to a buffered reader.
    	BufferedReader br = new BufferedReader(new FileReader(orderFilename));  
    	BufferedWriter bw = new BufferedWriter(new FileWriter(writingFile));
    	String line = null;  
    	// Get lines from the file one at a time until there are no more.
    	while ((line = br.readLine()) != null) {
    		// Process the line
    		bw.write(line);
    		bw.newLine();
    		
    		String[] tokens = line.split(",");
    		int tenantId = Integer.valueOf(tokens[0].trim());
    		String combineline = tokens[1] + "," + tokens[2] + "," + tokens[3] + "," + tokens[4] + "," + tokens[5] + "," + tokens[6] + "," + tokens[7];
    		insertOrderTable(tenantId, combineline);
    	} 
    	// Close the buffer and the underlying file.
    	br.close();
    	bw.close();
    }
    
    // Process one line in the order file - a single order.
    private void processOrder(String line) {	
    	try { 
    		// Parse the line item on comma, populate an Order object
    		String[] tokens = line.split(",");
    		Order order = new Order();  
    		order.setTenantId(Integer.valueOf(tokens[0].trim()));
    		order.setTimeMs(Long.valueOf(tokens[1].trim())); 
    		order.setOrderId(tokens[2].trim());
    		order.setCustomerId(tokens[3].trim());
    		order.setState(tokens[4].trim().toLowerCase());
    		order.setDescription(tokens[5].trim());
    		order.setQuantity(Integer.valueOf(tokens[6].trim())); 
    		order.setCost(Float.valueOf(tokens[7].trim())); 
    		// Validate and sttore the order in our cache of orders for later reporting.
    		updateOrder(order); 
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    
    // We're keeping a cache of orders we've processed.  When we see an order, see if its 
    // an order we've seen before. 
    private void updateOrder(Order newOrder) {
    	// Have we seen this order before?  If not, put it in the cache as the baseline.
    	boolean isNew = false; 
    	if (!orders.containsKey(newOrder.getOrderId())) {
    		orders.put(newOrder.getOrderId(), newOrder);
    		isNew = true; 
    	}
    	// Now look at the baseline order info in the cache and compare it to the new order info.
		Order oldOrder = orders.get(newOrder.getOrderId());
		// Is the new order info valid?  Are the fields valid and is it a valid state transition 
		// from the baseline order info?
		if ( 	(!newOrder.validateOrderFields()) ||  
				(newOrder.getTimeMs() < oldOrder.getTimeMs()) ||
				(!newOrder.getCustomerId().equals(oldOrder.getCustomerId())) || 
				(!MachineSpec.isValidTransition(machineSpec, oldOrder.getState(), newOrder.getState(), isNew)) 
			) {
			// The order info is not valid somehow.  Either the fields are not valid or its 
			// not a valid state transition.
			System.out.println("Flagging order " + newOrder.getOrderId());
			oldOrder.setFlagged(true);
		}
		// Put the new order info in the cache as the new basline.  If the old baseline was 
		// flagged, then this info is flagged too (even if the info itself was valid, the history of 
		// this order# shows the order is bad).
		newOrder.setFlagged(oldOrder.isFlagged());
		orders.put(oldOrder.getOrderId(), newOrder);
    }
    

    // Create a report on the processed orders.  
    private void makeReport() {
    	// Count up the orders in each state (including those "flagged").  Also sum up 
    	// the dollar value of orders in each state. 
    	Map<String,Integer> countMap = new HashMap<String,Integer>();
    	Integer countFlagged = 0; 
    	Map<String,Float> valueMap = new HashMap<String,Float>();
    	for (String key : orders.keySet()) {
    		Order o = orders.get(key);
    		if (!countMap.containsKey(o.getState())) {
    			countMap.put(o.getState(), 0);
    			valueMap.put(o.getState(), 0.0f);
    		}
    		if (o.isFlagged()) {
    			countFlagged++; 
    		}
    		else {
    			countMap.put(o.getState(), countMap.get(o.getState()) + 1);
    			valueMap.put(o.getState(), valueMap.get(o.getState()) + o.getCost());
    		}
    	}
    	
    	// For the report, for each state note if its a terminal state and output the metrics
    	// for that state.
    	for (String state : countMap.keySet()) {
    		Float cost = valueMap.get(state);
    		if (cost == null) {
    			cost = 0.0f;
    		}
    		String terminal = "";
    		if (MachineSpec.isTerminalState(machineSpec, state)) {
    			terminal = "(terminal)";
    		}
    		System.out.println(state + " " + countMap.get(state) + " $" + cost + " " + terminal);
    	}
    	// Plus output the count of flagged orders.
    	System.out.println("flagged " + countFlagged);
    }

    
    public void loadOrdersFile(String ordersFilePath) throws Exception {
        createConnection();
        createOrderTable();
        
        stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("select * from state_machines");
        rs.next();
        int num = rs.getInt(1);
        
        String json_string = getStateMachine(num);
        //System.out.println(json_string);
        
        machineSpec = parseJson(json_string);
        //dumpMachine(machineSpec);
        //processOrderFile(ordersFilePath);
        allorders(ordersFilePath);
        
        //insertRestaurant("LaVals", "Berkeley");
        //selectRestaurants();
        stmt.close();
        shutdown();
    }
    
    public void generateReport(String tenantID) throws Exception {
        createConnection();
        //createStateMachineTable();
        
       
        String json_string = getStateMachine(Integer.valueOf(tenantID));
        machineSpec = parseJson(json_string);
        System.out.println("Tru State");
        //dumpMachine(machineSpec);
        processOrderFile(writingFile);
        makeReport();
        //insertRestaurant("LaVals", "Berkeley");
        //selectRestaurants();
        
        
        shutdown();
    }
    
    
    private void createConnection() {
        try {
            Driver derbyEmbeddedDriver = new EmbeddedDriver();
            DriverManager.registerDriver(derbyEmbeddedDriver);
            conn = DriverManager.getConnection(DB_URL);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /*
    private void createTable() {
        try {
            stmt = conn.createStatement();
            stmt.execute("create table restaurants (" +
            		"id INT NOT NULL GENERATED ALWAYS AS IDENTITY " + 
            		"CONSTRAINT id_PK PRIMARY KEY," + 
            	    "name varchar(30) not null," + 
            		"city varchar(30) not null" + 
                    ")");
            stmt.close();
        }
        catch (SQLException sqlExcept) {
        	if(!tableAlreadyExists(sqlExcept)) {
        		sqlExcept.printStackTrace();
        	}
        }
    }
    */
    
    private boolean tableAlreadyExists(SQLException e) {
        boolean exists;
        if(e.getSQLState().equals("X0Y32")) {
            exists = true;
        } else {
            exists = false;
        }
        return exists;
    }
    
    private void createOrderTable() {
    	int max_chars = 1000;
    	try {
    		stmt = conn.createStatement();
    		String order_string = 
    				"create table order_list (id INT NOT NULL, order_line varchar(" + max_chars + ") not null)";
    		System.out.println(order_string);
    		stmt.execute(order_string);
    		stmt.close();
    	} catch (SQLException sqlExcept) {
    		if(!tableAlreadyExists(sqlExcept)) {
    			sqlExcept.printStackTrace();
    		}
    	}
    }
    
    private void createStateMachineTable() {
    	int max_chars = 1000;
    	try {
    		stmt = conn.createStatement();
    		String statement_string = 
    				"create table state_machines (id INT NOT NULL, json_string varchar(" + max_chars + ") not null)";
    		System.out.println(statement_string);
    		stmt.execute(statement_string);
    		stmt.close();
    	} catch (SQLException sqlExcept) {
    		if(!tableAlreadyExists(sqlExcept)) {
    			sqlExcept.printStackTrace();
    		}
    	}
    }
    
    private void insertOrderTable(int tenantId, String line) {
    	try {
    		stmt = conn.createStatement();
    		stmt.execute("insert into order_list (id, order_line) values (" + tenantId + ",'" + line + "')");
    		stmt.close();
    	} catch (SQLException sqlExcept) {
    		sqlExcept.printStackTrace();
    	}
    }
    
    private void insertStateMachine(int id, String json) {
    	try {
    		stmt = conn.createStatement();
    		stmt.execute("insert into state_machines (id,json_string) values (" + id + ",'" + json + "')");
    		stmt.close();
    	} catch (SQLException sqlExcept) {
    		sqlExcept.printStackTrace();
    	}
    }
    
    private String getStateMachine(int tenantId) {
    	String json_string = "placeholder";
    	try {
    		stmt = conn.createStatement();
    		ResultSet results = stmt.executeQuery("select * from state_machines where id = " + tenantId);
    		//ResultSetMetaData rsmd = results.getMetaData();
    		
    		while(results.next()) {
    			json_string = results.getString("json_string");
    		}
    		//System.out.println(json_string);
    		results.close();
    		stmt.close();
    	}
    	catch (SQLException sqlExcept) {
    		sqlExcept.printStackTrace();
    	}
    	return json_string;
    }
    /*
    private String getOrderLine(int tenantId) {
    	String order_line = "placeholder";
    	try {
    		stmt = conn.createStatement();
    		ResultSet results = stmt.executeQuery("select * from order_line where id = " + tenantId);
    		
    		while(results.next()) {
    			order_line = results.getString("order_line");
    		}
    		results.close();
    		stmt.close();
    	}
    	catch (SQLException sqlExcept) {
    		sqlExcept.printStackTrace();
    	}
    	return order_line;
    }
    */
    
    /*
    private void insertRestaurant(String restName, String cityName) {
        try {
            stmt = conn.createStatement();
            stmt.execute("insert into restaurants (name,city) values (" +
                    "'" + restName + "','" + cityName +"')");
            stmt.close();
        }
        catch (SQLException sqlExcept) {
            sqlExcept.printStackTrace();
        }
    }
    */
    
    /*
    private void selectRestaurants()
    {
        try {
            stmt = conn.createStatement();
            ResultSet results = stmt.executeQuery("select * from restaurants");
            ResultSetMetaData rsmd = results.getMetaData();
            int numberCols = rsmd.getColumnCount();
            for (int i=1; i<=numberCols; i++) {
                //print Column Names
                System.out.print(rsmd.getColumnLabel(i)+"\t\t");  
            }

            System.out.println("\n-------------------------------------------------");

            while(results.next()) {
                int id = results.getInt(1);
                String restName = results.getString(2);
                String cityName = results.getString(3);
                System.out.println(id + "\t\t" + restName + "\t\t" + cityName);
            }
            results.close();
            stmt.close();
        }
        catch (SQLException sqlExcept) {
            sqlExcept.printStackTrace();
        }
    }
    */
    
    private void shutdown() {
        try {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                DriverManager.getConnection(DB_URL + ";shutdown=true");
                conn.close();
            }           
        }
        catch (SQLException sqlExcept) {
        }
    }
        
    
    public static void main(String[] args) {
    	SqlDemo theApp = new SqlDemo();
    	String mode = null;

    	String tenantRegex = "\\d\\d\\d\\d\\d"; // regex for tenant id
    	
    	if (args.length == 2) {
    		mode = args[0];
    		if(mode.equals("--state")) {
    			String jsonFilePath = args[1];
    			try {
    				System.out.println(jsonFilePath);
					theApp.loadStateMachine(jsonFilePath);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		} else if(mode.equals("--order")) {
    			String ordersFilePath = args[1];
    			try {
					theApp.loadOrdersFile(ordersFilePath);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		} else if(mode.equals("--report")) {
    			String tenant_id_string = args[1];
    			
    			if(!tenant_id_string.matches(tenantRegex)) { // if tanant id doesn't match tenant regex, exit
    				System.out.println("Invalid tenant id");
    				System.exit(0);
    			}
    			try {
					theApp.generateReport(tenant_id_string);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		} else {
    			System.out.println("Invalid mode option");
    		}
    		
    		try {
    			//theApp.run(filename);
    		} catch(Exception e) {
    			System.out.println("Something bad happened!");
    			e.printStackTrace();
    		}
    	} else {
    		System.out.println("Wrong number of arguments");
    	}
    	
    }
}
