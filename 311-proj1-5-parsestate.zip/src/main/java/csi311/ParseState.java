package csi311;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;

import csi311.MachineSpec.StateTransitions; 

public class ParseState {
	
	public ParseState() {
	}
	
	
    public void run(String filename) throws Exception {
    	if (filename != null) {
    		processFile(filename);  
    	}
    }
    
    // to check if the string contains correct address information
    public static boolean stringContains(String inputStr, String[] items)
    {
        for(int i =0; i < items.length; i++) {
            if(inputStr.contains(items[i])) {
                return true;
            }
        }
        return false;
    }
    
    private void processFile(String filename) throws Exception {
    	System.out.println("Regex Co");
    	System.out.println("Processing file: " + filename); 
    	
    	// ArrayList for wrong Ids
    	ArrayList<String> wrongIds = new ArrayList<String>();
    	
    	int west = 0;
    	int east = 0;
    	int ave = 0;
    	int bway = 0;
    	int overlb = 0;
    	//int invalid = 0;
    	
    	BufferedReader br = new BufferedReader(new FileReader(filename));  
    	String line = null;
    	
    	// pattern for the package id
    	String pattern = "^\\d\\d\\d-[A-Z][A-Z][A-Z]-\\d\\d\\d\\d";
    	
        while ((line = br.readLine()) != null) {
        	
        	// to check if the address and weight are valid
        	boolean validAdd = false;
        	boolean validWeight = false;
        	
        	// to skip the blank line
        	if (line.trim().length() == 0) {
        		continue;
        	}
        	
        	// if line doesn't contain ",", skip the line
        	if (!line.contains(",")) {
        		continue;
        	}
        	
        	
        	String[] result = line.split(",");
    		
        	String pkgId = result[0].trim().toUpperCase();
    		//System.out.println("pkgId: " + pkgId);
    		
        	// if there's no pkgId, skip the line
        	if(pkgId.isEmpty()) {
    			continue;
    		}
        	
        	
    		// remove the blank space of the address
    		String pkgAdd = result[1].trim().replaceAll(" ", "");
    		//System.out.println("pkgAddress: " + pkgAdd);
        	
    		
    		// address keyword lists
    		String[] address = {"East", "E", "E.", "West", "W", "W.", "Avenue", "Ave", "Ave.", "Bway", "B'way", "Broadway", "Bway.", "B'way." };
    		String[] addSt = {"Street", "St", "St."};
    		String[] addWest = {"West", "W", "W."};
    		String[] addEast = {"East", "E", "E."};
    		String[] addAve = {"Avenue", "Ave", "Ave."};
    		String[] addBway = {"Broadway","Bway","B'way", "Bway.", "B'way."};
    		
    		// regex for each address
    		String east_address_regex = "[A-Za-z0-9]*(E.|E|East)[A-Za-z0-9]*(Street|St.|St)";
    		String west_address_regex = "[A-Za-z0-9]*(W.|W|West)[A-Za-z0-9]*(Street|St.|St)";
    		String avenue_address_regex = "[A-Za-z0-9]*(Ave.|Ave|Avenue)[A-Za-z0-9]*";
    		String broadway_address_regex = "[A-Za-z0-9]*(Broadway|Bway|B'way|Bway.|B'way.)[A-Za-z0-9]*";
    		String weight_regex = "[0-9]+[.]?[0-9]*";
    		
    		
    		if(!result[2].trim().matches(weight_regex)) {
    			// avoid the duplication
				   if(!wrongIds.contains(result[0])) {
					   wrongIds.add(result[0]);
				   }
    		} else {
    			validWeight = true;
    		}
    		
    		
    		// to dispense packages to each address
    		if(pkgId.matches(pattern) && stringContains(pkgAdd, addWest) && stringContains(pkgAdd, addSt) && pkgAdd.matches(west_address_regex) && validWeight) {
    			west += 1;
    			validAdd = true;
    		} else if(pkgId.matches(pattern) && stringContains(pkgAdd, addEast) && stringContains(pkgAdd, addSt) && pkgAdd.matches(east_address_regex) && validWeight) {
    			east += 1;
    			validAdd = true;
    		} else if(pkgId.matches(pattern) && stringContains(pkgAdd, addAve) && pkgAdd.matches(avenue_address_regex) && validWeight ) {
    			ave += 1;
    			validAdd = true;
    		} else if(pkgId.matches(pattern) && stringContains(pkgAdd, addBway) && pkgAdd.matches(broadway_address_regex) && validWeight ) {
    			bway += 1;
    			validAdd = true;
    		}    		
    		
    		
    		
    		try {
    			// weight of package
    			Float f = Float.valueOf(result[2]);   
    		    //System.out.println("Weight: " + f);	
    		    
    			
    			// check if the package with correct id and address is over 50 pounds
    		    if (f > 50 && pkgId.matches(pattern) && stringContains(pkgAdd,address) && validAdd && validWeight) {
				   overlb += 1;
    		    }    
    		} catch (NumberFormatException e) {
    			//System.out.println("Wrong weight input");
    		}
    		
    		
    		
    		    		
    		
    		
    		for(String str : result)
    		   {
    			   str.replaceAll("\n", "").replaceAll("\t", "").replaceAll("\r", "");
    			   
    			   // to check if there are more or less than two commas(,) 
    			   if(result.length > 3 || result.length <= 1) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    			   }
    			   
    			   
    			   // to check if the package Id matches the pattern
    			   if(!pkgId.matches(pattern)) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    				   //invalid += 1;
    			   }
    			   
    			   // to check if the address is valid
    			   if(!stringContains(pkgAdd, address)) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    			   }
    			   
    			   // to check if addresses are written in wrong format
    			   if(stringContains(pkgAdd, addWest) && !pkgAdd.matches(west_address_regex) ) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    			   }
    			   if(stringContains(pkgAdd, addEast) && !pkgAdd.matches(east_address_regex) ) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    			   }
    			   if(stringContains(pkgAdd, addAve) && !pkgAdd.matches(avenue_address_regex) ) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    			   }
    			   if(stringContains(pkgAdd, addBway) && !pkgAdd.matches(broadway_address_regex) ) {
    				   // avoid the duplication
    				   if(!wrongIds.contains(result[0])) {
    					   wrongIds.add(result[0]);
    				   }
    			   }
    			   
    			   
    			   
    			   
    			   
    			   // System.out.println(str);
    		   }
    		   // System.out.println("invalid Ids: " + invalid);
    	} 
    	br.close();
    	
    	
    	System.out.println("West: " + west);
    	System.out.println("East: " + east);
    	System.out.println("Ave: " + ave);
    	System.out.println("Bway: " + bway);
    	System.out.println(">50lbs: " + overlb);
    	System.out.println("Ids?: " + wrongIds);
    }

    
    public static void main(String[] args) {
    	ParseState theApp = new ParseState();
    	String filename = null; 
    	if (args.length > 0) {
    		filename = args[0]; 
    	}
    	try { 
    		theApp.run(filename);
    	}
    	catch (Exception e) {
    		System.out.println("Something bad happened!");
    		e.printStackTrace();
    	}
    }	
	
	

}
